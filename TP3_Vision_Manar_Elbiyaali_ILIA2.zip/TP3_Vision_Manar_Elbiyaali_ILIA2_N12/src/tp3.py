"""TP3 Vision par ordinateur — Manar Elbiyaali | ILIA2 | N°12.

Exemples:
 python -m src.tp3 ex1
 python -m src.tp3 ex2 --source images/demo_input.mp4
 python -m src.tp3 ex3     # nécessite detectron2 + poids de modèle (Colab conseillé)
 python -m src.tp3 ex4
 python -m src.tp3 ex5     # nécessite face_recognition
 python -m src.tp3 ex6     # nécessite face_recognition
 python -m src.tp3 ex7     # nécessite ultralytics et téléchargement du modèle
 python -m src.tp3 mini    # floutage automatique (sans identification)
"""
from __future__ import annotations
import argparse
from pathlib import Path
import time
import cv2
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
IMAGES=ROOT/'images'
RESULTS=ROOT/'results'
RESULTS.mkdir(exist_ok=True)

def load_image(path):
    p=Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Image introuvable: {p}")
    img=cv2.imread(str(p))
    if img is None:
        raise ValueError(f"Image illisible: {p}")
    return img

def save(name, image):
    dest=RESULTS/name
    if not cv2.imwrite(str(dest),image):
        raise IOError(f"Impossible de sauvegarder {dest}")
    print(f"Enregistré: {dest.relative_to(ROOT)}")
    return dest

def ex1(image=IMAGES/'image.jpg'):
    img=load_image(image)
    gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    blur=cv2.GaussianBlur(gray,(5,5),0)
    edges=cv2.Canny(blur,100,200)
    save('ex1_original.jpg',img)
    save('ex1_gris.jpg',gray)
    save('ex1_gaussien.jpg',blur)
    save('ex1_canny.jpg',edges)
    print('Matrice BGR:',img.shape,img.dtype,'; pixels de contour:',int(np.count_nonzero(edges)))
    return img,gray,blur,edges

def ex2(source='0', output=RESULTS/'ex2_video_gris.mp4', display=False, max_frames=0):
    # Les images traitées sont conservées en BGR pour un MP4 lisible sur davantage de lecteurs.
    src=int(source) if str(source).isdigit() else str(source)
    cap=cv2.VideoCapture(src)
    if not cap.isOpened(): raise RuntimeError(f"Source vidéo inaccessible: {source}")
    width=int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height=int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps=cap.get(cv2.CAP_PROP_FPS)
    if not fps or fps<=0: fps=20.0
    output=Path(output); output.parent.mkdir(parents=True,exist_ok=True)
    writer=cv2.VideoWriter(str(output),cv2.VideoWriter_fourcc(*'mp4v'),fps,(width,height),True)
    if not writer.isOpened(): cap.release(); raise RuntimeError('Impossible de créer le fichier MP4')
    n=0
    try:
        while True:
            ok,frame=cap.read()
            if not ok: break
            gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
            out=cv2.cvtColor(gray,cv2.COLOR_GRAY2BGR)
            writer.write(out)
            if n==0: save('ex2_premiere_image.jpg',gray)
            n+=1
            if display:
                cv2.imshow('Webcam / vidéo en gris (q pour quitter)',gray)
                if cv2.waitKey(1)&0xFF==ord('q'):break
            if max_frames and n>=max_frames:break
    finally:
        cap.release();writer.release()
        if display:cv2.destroyAllWindows()
    try: shown=output.resolve().relative_to(ROOT)
    except ValueError: shown=output
    print(f'Frames traitées: {n}; vidéo: {shown}')
    return n

def ex3(image=IMAGES/'image_objects.jpg', threshold=0.5):
    try:
        import torch
        import detectron2  # noqa: F401
    except ImportError as exc:
        raise RuntimeError("Detectron2 n'est pas installé : exécuter ex3 sur Google Colab "
                           "(voir notebooks/TP3_Colab_ex3_detectron2.ipynb)") from exc
    from detectron2.engine import DefaultPredictor
    from detectron2.config import get_cfg
    from detectron2 import model_zoo
    from detectron2.utils.visualizer import Visualizer
    from detectron2.data import MetadataCatalog
    img=load_image(image)
    config='COCO-InstanceSegmentation/mask_rcnn_R_50_FPN_3x.yaml'
    cfg=get_cfg();cfg.merge_from_file(model_zoo.get_config_file(config))
    cfg.MODEL.ROI_HEADS.SCORE_THRESH_TEST=threshold
    cfg.MODEL.WEIGHTS=model_zoo.get_checkpoint_url(config)
    cfg.MODEL.DEVICE='cuda' if torch.cuda.is_available() else 'cpu'
    model=DefaultPredictor(cfg)
    t=time.perf_counter();prediction=model(img);secs=time.perf_counter()-t
    instance=prediction['instances'].to('cpu')
    vis=Visualizer(img[:,:,::-1],MetadataCatalog.get(cfg.DATASETS.TRAIN[0]),scale=1)
    rendered=vis.draw_instance_predictions(instance).get_image()[:,:,::-1]
    save(f'ex3_mask_rcnn_seuil_{threshold}.jpg',rendered)
    labels=MetadataCatalog.get(cfg.DATASETS.TRAIN[0]).thing_classes
    print('Objets:',[(labels[int(c)],round(float(sc),2)) for c,sc in zip(instance.pred_classes,instance.scores)],f'; temps {secs:.3f}s, seuil {threshold}')
    return secs

def face_rectangles(img):
    try:
        import dlib
    except ImportError as exc:
        raise RuntimeError('Installer dlib (voir README)') from exc
    rgb_gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    return dlib.get_frontal_face_detector()(rgb_gray,1)

def face_locations(img):
    """Boîtes (haut, droite, bas, gauche) du détecteur Dlib frontal, format face_recognition.
    Le détecteur par défaut de face_recognition avait donné un faux positif sur l'écusson
    de la combinaison (image people.jpg) : on réutilise donc le même détecteur que l'ex. 4."""
    h,w=img.shape[:2]
    return [(max(0,f.top()),min(w,f.right()),min(h,f.bottom()),max(0,f.left())) for f in face_rectangles(img)]

def ex4(image=IMAGES/'people.jpg'):
    img=load_image(image); faces=face_rectangles(img)
    for face in faces:
        cv2.rectangle(img,(face.left(),face.top()),(face.right(),face.bottom()),(0,255,0),2)
    save('ex4_visages_dlib.jpg',img)
    print('Nombre de visages détectés:',len(faces))
    return len(faces)

def ex5(ref=IMAGES/'ref.jpg', test=IMAGES/'test.jpg', tolerance=0.6):
    import face_recognition
    refimg=face_recognition.load_image_file(str(ref)); testimg=face_recognition.load_image_file(str(test))
    known=face_recognition.face_encodings(refimg,known_face_locations=face_locations(refimg[:,:,::-1]))
    unknown=face_recognition.face_encodings(testimg,known_face_locations=face_locations(testimg[:,:,::-1]))
    if not known:raise ValueError('Aucun visage de référence détecté')
    if not unknown:raise ValueError('Aucun visage test détecté')
    print(f'{len(unknown)} visage(s) test ; comparaison avec le premier visage de référence')
    for i,encoding in enumerate(unknown,1):
        distance=float(face_recognition.face_distance([known[0]],encoding)[0])
        match=bool(face_recognition.compare_faces([known[0]],encoding,tolerance=tolerance)[0])
        print(f'Visage {i}: même personne = {match}, distance={distance:.4f}, seuil={tolerance}')
    return len(unknown)

def eye_aspect_ratio(eye):
    """EAR = (||p2-p6|| + ||p3-p5||) / (2 ||p1-p4||) pour 6 points d'un oeil."""
    p=np.asarray(eye,dtype=float)
    if len(p)<6: raise ValueError('Il faut 6 points')
    return float((np.linalg.norm(p[1]-p[5])+np.linalg.norm(p[2]-p[4]))/(2*np.linalg.norm(p[0]-p[3])))

def ex6(image=IMAGES/'people.jpg'):
    import face_recognition
    img=load_image(image); rgb=cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
    landmarks=face_recognition.face_landmarks(rgb,face_locations=face_locations(img),model='large')
    count=0
    for face in landmarks:
        for name,points in face.items():
            for x,y in points:
                cv2.circle(img,(x,y),2,(0,0,255),-1)
                count+=1
    for i,face in enumerate(landmarks,1):
        left=eye_aspect_ratio(face['left_eye']); right=eye_aspect_ratio(face['right_eye'])
        print(f'Visage {i}: EAR oeil gauche={left:.3f}, oeil droit={right:.3f}, moyenne={(left+right)/2:.3f}')
    save('ex6_landmarks.jpg',img)
    print(f'Visages: {len(landmarks)}; points dessinés: {count}')
    return len(landmarks)

def ex7(image=IMAGES/'image_objects.jpg', threshold=0.5, segment=False, repeat=10):
    from ultralytics import YOLO
    model=YOLO('yolov8n-seg.pt' if segment else 'yolov8n.pt')  # poids téléchargés automatiquement
    img=load_image(image)
    pred=model.predict(img,conf=threshold,verbose=False)[0]   # échauffement (1re inférence plus lente)
    times=[]
    for _ in range(repeat):
        t=time.perf_counter();pred=model.predict(img,conf=threshold,verbose=False)[0];times.append(time.perf_counter()-t)
    secs=float(np.median(times))
    save('ex7_yolo_seg.jpg' if segment else 'ex7_yolo_detect.jpg',pred.plot())
    objets=[(pred.names[int(c)],round(float(s),2)) for c,s in zip(pred.boxes.cls,pred.boxes.conf)]
    print('Objets:',objets)
    print(f'Temps médian sur {repeat} inférences: {secs:.3f}s; masques présents={pred.masks is not None}')
    return secs

def mini(image=IMAGES/'people.jpg'):
    """Mini-projet 4 : anonymiser les régions faciales, sans reconnaissance d'identité."""
    img=load_image(image)
    faces=face_rectangles(img)
    for face in faces:
        x1=max(0,face.left());y1=max(0,face.top())
        x2=min(img.shape[1],face.right());y2=min(img.shape[0],face.bottom())
        roi=img[y1:y2,x1:x2]
        if roi.size:
            # Noyau impair adapté à la taille de la zone
            k=max(3,min(99,(min(roi.shape[:2])//2)*2+1))
            img[y1:y2,x1:x2]=cv2.GaussianBlur(roi,(k,k),0)
    save('mini_visages_floutes.jpg',img)
    print(f'Mini-projet: {len(faces)} visage(s) flouté(s)')
    return len(faces)

def main():
    p=argparse.ArgumentParser(description='TP3 Vision par ordinateur - Manar Elbiyaali - ILIA2 N12')
    p.add_argument('exercise',choices=['ex1','ex2','ex3','ex4','ex5','ex6','ex7','mini'])
    p.add_argument('--source',default='0',help='Webcam 0 ou chemin vidéo pour ex2')
    p.add_argument('--image',default=None,help='Image personnalisée')
    p.add_argument('--threshold',type=float,default=.5)
    p.add_argument('--segment',action='store_true',help='Ex7: yolov8n-seg.pt')
    p.add_argument('--display',action='store_true',help='Afficher les frames ex2 (q pour quitter)')
    args=p.parse_args()
    try:
        run(args)
    except RuntimeError as exc:
        raise SystemExit(f'Erreur: {exc}')

def run(args):
    if args.exercise=='ex1':ex1(args.image or IMAGES/'image.jpg')
    elif args.exercise=='ex2':ex2(args.source,display=args.display)
    elif args.exercise=='ex3':ex3(args.image or IMAGES/'image_objects.jpg',args.threshold)
    elif args.exercise=='ex4':ex4(args.image or IMAGES/'people.jpg')
    elif args.exercise=='ex5':ex5()
    elif args.exercise=='ex6':ex6(args.image or IMAGES/'people.jpg')
    elif args.exercise=='ex7':ex7(args.image or IMAGES/'image_objects.jpg',args.threshold,args.segment)
    elif args.exercise=='mini':mini(args.image or IMAGES/'people.jpg')
if __name__=='__main__':main()
