from pathlib import Path
import cv2
from src.tp3 import ROOT, ex1, ex2

def test_images_presentes():
    for name in ['image.jpg','image_objects.jpg','people.jpg','ref.jpg','test.jpg']:
        assert (ROOT/'images'/name).is_file()

def test_ex1():
    im,gray,blur,edges=ex1()
    assert im.ndim==3 and gray.ndim==2 and edges.shape==gray.shape
    assert cv2.countNonZero(edges)>0

def test_ex2_fichier(tmp_path):
    out=tmp_path/'t.mp4'   # ne pas écraser results/ex2_video_gris.mp4
    assert ex2(str(ROOT/'images'/'demo_input.mp4'),output=out,max_frames=3)==3
    assert out.is_file()

def test_ear():
    from src.tp3 import eye_aspect_ratio
    ouvert=[(0,0),(1,1),(2,1),(3,0),(2,-1),(1,-1)]
    ferme=[(0,0),(1,.1),(2,.1),(3,0),(2,-.1),(1,-.1)]
    assert eye_aspect_ratio(ouvert)>eye_aspect_ratio(ferme)
