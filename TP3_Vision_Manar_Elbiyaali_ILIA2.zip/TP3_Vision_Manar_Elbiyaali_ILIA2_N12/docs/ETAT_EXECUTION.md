# État de vérification — TP3

**Étudiante : Manar Elbiyaali | ILIA2 | n°12**
Environnement : Linux, Python 3.13, CPU, OpenCV 5, dlib 20, face_recognition 1.3, ultralytics 8.4.

| Partie | Statut | Preuve |
|---|---|---|
| Exercice 1 — OpenCV (gris, Gaussien, Canny) | Exécuté | `results/ex1_*.jpg` |
| Exercice 2 — vidéo fichier → gris, MP4 | Exécuté (36 images) | `results/ex2_*` |
| Exercice 2 — webcam réelle | Non testée (pas de webcam) ; `ex2 --source 0 --display` | — |
| Exercice 3 — Detectron2 Mask R-CNN | **Non exécuté** : installation et poids inaccessibles ici ; notebook Colab fourni | `notebooks/TP3_Colab_ex3_detectron2.ipynb` |
| Exercice 4 — Dlib | Exécuté (1 visage) | `results/ex4_visages_dlib.jpg` |
| Exercice 5 — face_recognition | Exécuté (distance 0,0504 → même personne) | `docs/execution_log.txt` |
| Exercice 6 — landmarks + EAR | Exécuté (72 points, EAR ≈ 0,34) | `results/ex6_landmarks.jpg` |
| Exercice 7 — YOLOv8n et YOLOv8n-seg | Exécuté (≈ 0,06 s et ≈ 0,09 s, CPU) | `results/ex7_*.jpg` |
| Mini-projet — floutage de visages | Exécuté | `results/mini_visages_floutes.jpg` |
| Tests pytest | 4 réussis | `docs/execution_log.txt` |

Corrections apportées : le test ex2 n'écrase plus la vidéo de résultat ; ex5/ex6 utilisent le détecteur de l'ex. 4 (le détecteur par défaut de `face_recognition` détectait à tort l'écusson comme visage) ; ajout du calcul EAR ; mesure de temps YOLO avec échauffement et médiane ; message clair si Detectron2 est absent.
